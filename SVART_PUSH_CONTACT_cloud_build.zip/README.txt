SVART PUSH CONTACT - SOURCE PROJECT

Isi:
- Import file TXT atau VCF.
- Membaca nomor telepon dan menghapus duplikat dalam file.
- Menyimpan kontak ke buku telepon Android dengan nama SELLER SVART 001, 002, dst.
- Memeriksa nomor yang sudah ada agar tidak membuat duplikat.
- Tidak mengirim pesan WhatsApp otomatis dan tidak mengakali limit WhatsApp.

Format TXT:
Satu nomor per baris:
081234567890
6281234567890

Boleh juga:
Pelanggan A,081234567890

Build menjadi APK:
1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
5. Pindahkan APK ke Redmi 13C dan pasang. Berikan izin kontak saat diminta.

Catatan:
Ini adalah SOURCE PROJECT Android, bukan file APK siap pasang. Build memerlukan Android Studio, JDK, dan Android SDK.
Simpan hanya nomor yang pemiliknya setuju untuk disimpan/dihubungi.
