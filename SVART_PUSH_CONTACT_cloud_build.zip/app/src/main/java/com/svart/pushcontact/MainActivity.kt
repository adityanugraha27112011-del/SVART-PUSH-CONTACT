package com.svart.pushcontact

import android.Manifest
import android.app.Activity
import android.content.ContentProviderOperation
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val requestContacts = 42
    private val pickFile = 43
    private var imported: List<String> = emptyList()
    private lateinit var status: TextView
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "SVART PUSH CONTACT"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val info = TextView(this).apply {
            text = "Import nomor dari TXT atau VCF, lalu simpan sebagai kontak dengan nama SELLER SVART 001, 002, dan seterusnya."
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        val importButton = Button(this).apply {
            text = "PILIH FILE TXT / VCF"
            setOnClickListener { openFilePicker() }
        }
        status = TextView(this).apply {
            text = "Belum ada file dipilih."
            textSize = 15f
            setPadding(0, 20, 0, 20)
        }
        saveButton = Button(this).apply {
            text = "SIMPAN KONTAK"
            isEnabled = false
            setOnClickListener { requestPermissionAndSave() }
        }
        val note = TextView(this).apply {
            text = "Gunakan hanya nomor yang pemiliknya setuju untuk disimpan dan dihubungi. Aplikasi ini tidak mengirim pesan otomatis dan tidak melewati batas WhatsApp."
            textSize = 13f
            setPadding(0, 28, 0, 0)
        }
        root.addView(title)
        root.addView(info)
        root.addView(importButton)
        root.addView(status)
        root.addView(saveButton)
        root.addView(note)
        setContentView(root)
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "text/vcard", "text/x-vcard"))
        }
        startActivityForResult(intent, pickFile)
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val content = BufferedReader(InputStreamReader(stream)).readText()
                    imported = if (content.contains("BEGIN:VCARD", ignoreCase = true)) {
                        parseVcf(content)
                    } else {
                        parseTxt(content)
                    }
                }
                status.text = "Nomor terbaca: ${imported.size}\nDuplikat dalam file dihapus."
                saveButton.isEnabled = imported.isNotEmpty()
            } catch (e: Exception) {
                imported = emptyList()
                status.text = "Gagal membaca file: ${e.message}"
                saveButton.isEnabled = false
            }
        }
    }

    private fun parseVcf(text: String): List<String> {
        val result = mutableListOf<String>()
        var inCard = false
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.equals("BEGIN:VCARD", true)) inCard = true
            if (inCard && line.startsWith("TEL", true)) {
                val value = line.substringAfter(':', "").trim().replace(Regex("[^+0-9]"), "")
                if (value.count { it.isDigit() } >= 6) result.add(value)
            }
            if (line.equals("END:VCARD", true)) inCard = false
        }
        return result.distinct()
    }

    private fun parseTxt(text: String): List<String> {
        return text.lineSequence().mapNotNull { line ->
            // Satu nomor per baris; boleh juga "nama,nomor" atau "nama;nomor".
            val candidate = line.trim().substringAfterLast(';').substringAfterLast(',')
                .replace(Regex("[^+0-9]"), "")
            candidate.takeIf { it.count { c -> c.isDigit() } >= 6 }
        }.distinct()
    }

    private fun requestPermissionAndSave() {
        val needed = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)
        val missing = needed.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing) requestPermissions(needed, requestContacts) else saveContacts()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestContacts) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                saveContacts()
            } else {
                Toast.makeText(this, "Izin kontak diperlukan untuk menyimpan nomor.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveContacts() {
        var saved = 0
        var skipped = 0
        imported.forEachIndexed { index, number ->
            if (alreadyExists(number)) {
                skipped++
            } else {
                val displayName = "SELLER SVART ${String.format("%03d", index + 1)}"
                try {
                    val ops = ArrayList<ContentProviderOperation>()
                    ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
                    ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, displayName).build())
                    ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build())
                    contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                    saved++
                } catch (_: Exception) { skipped++ }
            }
        }
        status.text = "Selesai.\nTersimpan: $saved\nDilewati (sudah ada/gagal): $skipped"
        saveButton.isEnabled = false
        Toast.makeText(this, "Kontak berhasil diproses.", Toast.LENGTH_LONG).show()
    }

    private fun alreadyExists(number: String): Boolean {
        val uri: Uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
        )
        contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
            .use { return it != null && it.moveToFirst() }
    }
}
